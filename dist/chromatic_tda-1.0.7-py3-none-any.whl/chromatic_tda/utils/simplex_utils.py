def dimension(simplex) -> int:
    return len(simplex) - 1

    